package com.cy.ease.compose.ext

import androidx.compose.foundation.Indication
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp

fun Modifier.paddingHorizontal(padding: Dp) = padding(horizontal = padding)

fun Modifier.paddingVertical(padding: Dp) = padding(vertical = padding)

fun Modifier.paddingTop(padding: Dp) = padding(top = padding)

fun Modifier.paddingBottom(padding: Dp) = padding(bottom = padding)

fun Modifier.paddingStart(padding: Dp) = padding(start = padding)

fun Modifier.paddingEnd(padding: Dp) = padding(end = padding)

fun Modifier.clickableOnce(
    interactionSource: MutableInteractionSource?,
    indication: Indication?,
    enabled: Boolean = true,
    onClickLabel: String? = null,
    role: Role? = null,
    interval: Long = 500L,
    onClick: () -> Unit
): Modifier = composed {
    var lastClickTime by remember { mutableLongStateOf(0L) }
    clickable(
        interactionSource = interactionSource,
        indication = indication,
        enabled = enabled,
        onClickLabel = onClickLabel,
        role = role
    ) {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastClickTime > interval) {
            lastClickTime = currentTime
            onClick()
        }
    }
}


inline fun buildModifier(builderAction: MutableList<Modifier>.() -> Unit): Modifier {
    return buildList(builderAction).fold(Modifier as Modifier) { acc, modifier ->
        acc then modifier
    }
}