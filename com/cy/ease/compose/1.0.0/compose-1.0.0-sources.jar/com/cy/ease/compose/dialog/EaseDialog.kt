package com.cy.ease.compose.dialog

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import com.cy.ease.compose.ext.toColor
import kotlinx.coroutines.delay

/**
 * 全屏显示的Dialog
 *
 * @param modifier [Modifier]
 * @param contentAlignment [content]的显示位置
 * @param dismissOnBackPress 是否点击返回键消失
 * @param dismissOnClickOutside 是否点击外部消失
 * @param backgroundColor Scrim颜色
 * @param dismissDelay 自动消失时间
 * @param isInterceptBackEvent 是否拦截返回事件，默认拦截
 * @param onDismiss 消失回调
 * @param content 需要显示的内容
 */
@Composable
fun FullDialog(
    modifier: Modifier = Modifier,
    contentAlignment: Alignment = Alignment.Center,
    dismissOnBackPress: Boolean = true,
    dismissOnClickOutside: Boolean = true,
    backgroundColor: Color = "#7F000000".toColor(),
    dismissDelay: Long? = null,
    isInterceptBackEvent: Boolean = true,
    onDismiss: () -> Unit,
    content: @Composable () -> Unit
) {
    dismissDelay?.let {
        LaunchedEffect(Unit) {
            delay(dismissDelay)
            onDismiss()
        }
    }
    ModalDialog {
        Box(
            modifier = Modifier.fillMaxSize()
                .background(backgroundColor)
                .then(modifier)
                .clickable(
                    enabled = dismissOnClickOutside,
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                ),
            contentAlignment = contentAlignment
        ) {
            //防止点击Content触发onDismiss
            Box(
                modifier = Modifier.clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                )
            ) {
                content()
            }
        }
        if (isInterceptBackEvent) {
            BackHandler {
                if (dismissOnBackPress) {
                    onDismiss()
                }
            }
        }
    }
}

/**
 * 带动画的全屏显示Dialog
 *
 * @param modifier [Modifier]
 * @param contentAlignment [content]的显示位置
 * @param dialogState Dialog的显示状态
 * @param dismissOnBackPress 是否点击返回键消失
 * @param dismissOnClickOutside 是否点击外部消失
 * @param backgroundColor Scrim颜色
 * @param isAnimateEnable 是否启用动画
 * @param duration 动画时长
 * @param dismissDelay 自动消失时间
 * @param isInterceptBackEvent 是否拦截返回事件，默认拦截
 * @param onDismiss 消失回调
 * @param content 需要显示的内容
 */
@Composable
fun EaseDialog(
    dialogState: DialogState,
    modifier: Modifier = Modifier,
    contentAlignment: Alignment = Alignment.Center,
    dismissOnBackPress: Boolean = true,
    dismissOnClickOutside: Boolean = true,
    backgroundColor: Color = "#7F000000".toColor(),
    isAnimateEnable: Boolean = true,
    duration: Int = 300,
    dismissDelay: Long? = null,
    isInterceptBackEvent: Boolean = true,
    onDismiss: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    LaunchedEffect(dialogState.targetVisible) {
        if (dialogState.targetVisible) {
            dialogState.currentVisible = true
        }
    }
    val color by animateColorAsState(
        targetValue = if (dialogState.targetVisible) backgroundColor else Color.Transparent,
        animationSpec = tween(duration),
        finishedListener = {
            if (!dialogState.targetVisible) {
                dialogState.currentVisible = false
            }
        }
    )
    val alpha by animateFloatAsState(
        targetValue = if (dialogState.targetVisible) 1f else 0f,
        animationSpec = if (isAnimateEnable) tween(duration) else tween(0)
    )
    if (!dialogState.currentVisible) return
    FullDialog(
        modifier = modifier,
        contentAlignment = contentAlignment,
        dismissOnBackPress = dismissOnBackPress,
        dismissOnClickOutside = dismissOnClickOutside,
        backgroundColor = color,
        dismissDelay = dismissDelay,
        isInterceptBackEvent = isInterceptBackEvent,
        onDismiss = { if (onDismiss == null) dialogState.dismiss() else onDismiss() },
        content = {
            if (isAnimateEnable) {
                Box(Modifier.alpha(alpha)) { content() }
            } else {
                content()
            }
        },
    )
}

/**
 * 显示在顶部的Dialog，带slide动画
 *
 * @param modifier [Modifier]
 * @param dialogState Dialog的显示状态
 * @param dismissOnBackPress 是否点击返回键消失
 * @param dismissOnClickOutside 是否点击外部消失
 * @param backgroundColor Scrim颜色
 * @param duration 动画时长
 * @param dismissDelay 自动消失时间
 * @param isInterceptBackEvent 是否拦截返回事件，默认拦截
 * @param onDismiss 消失回调
 * @param content 需要显示的内容
 */
@Composable
fun TopEaseDialog(
    dialogState: DialogState,
    modifier: Modifier = Modifier,
    dismissOnBackPress: Boolean = true,
    dismissOnClickOutside: Boolean = true,
    backgroundColor: Color = "#7F000000".toColor(),
    duration: Int = 300,
    dismissDelay: Long? = null,
    isInterceptBackEvent: Boolean = true,
    onDismiss: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val visibleState = remember { MutableTransitionState(false) }
    LaunchedEffect(dialogState.targetVisible) {
        visibleState.targetState = dialogState.targetVisible
    }
    EaseDialog(
        modifier = modifier,
        contentAlignment = Alignment.TopCenter,
        dialogState = dialogState,
        dismissOnBackPress = dismissOnBackPress,
        dismissOnClickOutside = dismissOnClickOutside,
        backgroundColor = backgroundColor,
        duration = duration,
        dismissDelay = dismissDelay,
        isInterceptBackEvent = isInterceptBackEvent,
        onDismiss = onDismiss,
        isAnimateEnable = false
    ) {
        AnimatedVisibility(
            visibleState = visibleState,
            enter = slideInVertically(
                animationSpec = tween(duration),
                initialOffsetY = { -it }
            ) + fadeIn(animationSpec = tween(duration)),
            exit = slideOutVertically(
                animationSpec = tween(duration),
                targetOffsetY = { -it }
            ) + fadeOut(animationSpec = tween(duration))
        ) {
            content()
        }
    }
}

/**
 * 显示在中心的Dialog，带渐入渐出动画
 *
 * @param modifier [Modifier]
 * @param dialogState Dialog的显示状态
 * @param dismissOnBackPress 是否点击返回键消失
 * @param dismissOnClickOutside 是否点击外部消失
 * @param backgroundColor Scrim颜色
 * @param duration 动画时长
 * @param dismissDelay 自动消失时间
 * @param isInterceptBackEvent 是否拦截返回事件，默认拦截
 * @param onDismiss 消失回调
 * @param content 需要显示的内容
 */
@Composable
fun CenterEaseDialog(
    dialogState: DialogState,
    modifier: Modifier = Modifier,
    dismissOnBackPress: Boolean = true,
    dismissOnClickOutside: Boolean = true,
    backgroundColor: Color = "#7F000000".toColor(),
    duration: Int = 300,
    dismissDelay: Long? = null,
    isInterceptBackEvent: Boolean = true,
    onDismiss: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val visibleState = remember { MutableTransitionState(false) }
    LaunchedEffect(dialogState.targetVisible) {
        visibleState.targetState = dialogState.targetVisible
    }
    EaseDialog(
        modifier = modifier,
        contentAlignment = Alignment.Center,
        dialogState = dialogState,
        dismissOnBackPress = dismissOnBackPress,
        dismissOnClickOutside = dismissOnClickOutside,
        backgroundColor = backgroundColor,
        duration = duration,
        dismissDelay = dismissDelay,
        isInterceptBackEvent = isInterceptBackEvent,
        onDismiss = onDismiss,
        isAnimateEnable = true
    ) {
        content()
    }
}

/**
 * 显示在底部的Dialog，带slide动画
 *
 * @param modifier [Modifier]
 * @param dialogState Dialog的显示状态
 * @param dismissOnBackPress 是否点击返回键消失
 * @param dismissOnClickOutside 是否点击外部消失
 * @param backgroundColor Scrim颜色
 * @param duration 动画时长
 * @param dismissDelay 自动消失时间
 * @param isInterceptBackEvent 是否拦截返回事件，默认拦截
 * @param onDismiss 消失回调
 * @param content 需要显示的内容
 */
@Composable
fun BottomEaseDialog(
    dialogState: DialogState,
    modifier: Modifier = Modifier,
    dismissOnBackPress: Boolean = true,
    dismissOnClickOutside: Boolean = true,
    backgroundColor: Color = "#7F000000".toColor(),
    duration: Int = 300,
    dismissDelay: Long? = null,
    isInterceptBackEvent: Boolean = true,
    onDismiss: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val visibleState = remember { MutableTransitionState(false) }
    LaunchedEffect(dialogState.targetVisible) {
        visibleState.targetState = dialogState.targetVisible
    }
    EaseDialog(
        modifier = modifier,
        contentAlignment = Alignment.BottomCenter,
        dialogState = dialogState,
        dismissOnBackPress = dismissOnBackPress,
        dismissOnClickOutside = dismissOnClickOutside,
        backgroundColor = backgroundColor,
        duration = duration,
        dismissDelay = dismissDelay,
        isInterceptBackEvent = isInterceptBackEvent,
        onDismiss = onDismiss,
        isAnimateEnable = false
    ) {
        AnimatedVisibility(
            visibleState = visibleState,
            enter = slideInVertically(
                animationSpec = tween(duration),
                initialOffsetY = { it }
            ) + fadeIn(animationSpec = tween(duration)),
            exit = slideOutVertically(
                animationSpec = tween(duration),
                targetOffsetY = { it }
            ) + fadeOut(animationSpec = tween(duration))
        ) {
            content()
        }
    }
}

@Stable
class DialogState(initial: Boolean) {
    val isVisible: Boolean
        get() = currentVisible
    internal var currentVisible by mutableStateOf(initial)
    internal var targetVisible by mutableStateOf(initial)
        private set

    fun show() {
        targetVisible = true
    }

    fun dismiss() {
        targetVisible = false
    }
}

@Composable
fun rememberEaseDialogState(initial: Boolean = true): DialogState {
    return remember { DialogState(initial) }
}