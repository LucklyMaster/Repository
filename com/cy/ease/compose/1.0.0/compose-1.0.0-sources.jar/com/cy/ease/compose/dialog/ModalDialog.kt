package com.cy.ease.compose.dialog

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import android.view.Window
import android.view.WindowManager
import androidx.activity.ComponentDialog
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.rememberCompositionContext
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.dialog
import androidx.compose.ui.semantics.semantics
import androidx.core.view.WindowCompat
import androidx.lifecycle.findViewTreeLifecycleOwner
import androidx.lifecycle.findViewTreeViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.findViewTreeSavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.cy.ease.compose.R
import java.util.UUID

/**
 * 一个拥有Window的Dialog，无任何UI属性
 */
@Composable
fun ModalDialog(content: @Composable () -> Unit) {
    val view = LocalView.current
    val context = LocalContext.current
    val composition = rememberCompositionContext()
    val id = rememberSaveable { UUID.randomUUID() }

    DisposableEffect(view) {
        val contentView: ComposeView

        val dialog = ComponentDialog(context, R.style.ModalDialog).apply {
            contentView = ComposeView(context).apply {
                setTag(androidx.compose.ui.R.id.compose_view_saveable_id_tag, "Modal_$id")
                setParentCompositionContext(composition)
                setContent {
                    val localWindow = window ?: error(
                        "Attempted to get the dialog's window without content."
                    )
                    Box(Modifier.fillMaxSize().semantics { dialog() }) {
                        CompositionLocalProvider(LocalModalWindow provides localWindow) {
                            content()
                        }
                    }
                }
            }

            setContentView(contentView)

            contentView.setViewTreeLifecycleOwner(view.findViewTreeLifecycleOwner())
            contentView.setViewTreeViewModelStoreOwner(view.findViewTreeViewModelStoreOwner())
            contentView.setViewTreeSavedStateRegistryOwner(
                view.findViewTreeSavedStateRegistryOwner()
            )

            setCancelable(false)
            setCanceledOnTouchOutside(false)
        }

        val window = requireNotNull(dialog.window) {
            "Tried to use a Modal without a window. Is your parent composable attached to an Activity?"
        }
        window.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window.setDimAmount(0f)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
        } else {
            @Suppress("DEPRECATION")
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }

        val hostWindow = context.findActivity()?.window
        if (hostWindow != null) {
            syncSystemUiAppearance(from = hostWindow, to = window)
        }

        dialog.show()

        onDispose {
            contentView.disposeComposition()
            dialog.dismiss()
        }
    }
}

/**
 * The CompositionLocal containing the current [Window].
 */
val LocalModalWindow = staticCompositionLocalOf<Window> {
    error(
        "CompositionLocal LocalModalWindow not present – did you try to access the modal window without a modal visible on the screen?"
    )
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun syncSystemUiAppearance(from: Window, to: Window) {
    val hostController = WindowCompat.getInsetsController(from, from.decorView)
    val modalController = WindowCompat.getInsetsController(to, to.decorView)
    modalController.isAppearanceLightStatusBars = hostController.isAppearanceLightStatusBars
    modalController.isAppearanceLightNavigationBars = hostController.isAppearanceLightNavigationBars
}