package com.cy.ease.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import com.cy.ease.kit.TaskFlow

@Composable
fun rememberTaskFlow(): TaskFlow {
    val scope = rememberCoroutineScope()
    val taskFlow = remember { TaskFlow(scope) }

    DisposableEffect(Unit) {
        onDispose { taskFlow.stop() }
    }
    return taskFlow
}