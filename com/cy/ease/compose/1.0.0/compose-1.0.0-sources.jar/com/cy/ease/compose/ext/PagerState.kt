package com.cy.ease.compose.ext

import androidx.compose.foundation.pager.PagerState

val PagerState.isLastPage: Boolean
    get() = currentPage == pageCount - 1

val PagerState.isFirstPage: Boolean
    get() = currentPage == 0

suspend fun PagerState.animateScrollToNext() {
    animateScrollToPage(currentPage + 1)
}

suspend fun PagerState.animateScrollToPre() {
    animateScrollToPage(currentPage - 1)
}