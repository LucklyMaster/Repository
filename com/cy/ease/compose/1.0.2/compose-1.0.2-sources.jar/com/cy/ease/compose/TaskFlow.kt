package com.cy.ease.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import com.cy.ease.kit.FlowTask

@Composable
fun rememberFlowTask(): FlowTask {
    val scope = rememberCoroutineScope()
    val flowTask = remember { FlowTask(scope) }

    DisposableEffect(Unit) {
        onDispose { flowTask.stop() }
    }
    return flowTask
}