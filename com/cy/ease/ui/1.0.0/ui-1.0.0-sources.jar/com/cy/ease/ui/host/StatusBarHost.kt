package com.cy.ease.ui.host

import android.content.Context
import android.util.AttributeSet
import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.cy.ease.kit.ext.dp2pxi

/**
 * 状态栏占位
 * @author: MasterChan
 * @date: 2024-09-03 9:31
 */
class StatusBarHost @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : View(context, attrs, defStyleAttr, defStyleRes) {

    private var hostHeight = -1

    init {
        ViewCompat.setOnApplyWindowInsetsListener(this) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            hostHeight = systemBars.top
            insets
        }
    }


    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (isInEditMode) {
            super.onMeasure(
                widthMeasureSpec,
                MeasureSpec.makeMeasureSpec(context.dp2pxi(30), MeasureSpec.EXACTLY)
            )
        } else {
            if (hostHeight == -1) {
                super.onMeasure(widthMeasureSpec, heightMeasureSpec)
            } else {
                super.onMeasure(
                    widthMeasureSpec,
                    MeasureSpec.makeMeasureSpec(hostHeight, MeasureSpec.EXACTLY)
                )
            }
        }
    }
}