package com.cy.ease.ui.shadow

import android.content.Context
import android.util.AttributeSet
import android.widget.RelativeLayout

/**
 * ShapedRelativeLayout
 * @author: MasterChan
 * @date: 2023-03-11 21:36
 */
open class ShadowRelativeLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : RelativeLayout(context, attrs, defStyleAttr),
    IShadowView by ShadowViewDelegate(context, attrs) {

    init {
        this.init()
    }

    protected open fun init() {
        into(this)
    }
}