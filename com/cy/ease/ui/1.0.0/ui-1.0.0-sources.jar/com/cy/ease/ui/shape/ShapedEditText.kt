package com.cy.ease.ui.shape

import android.content.Context
import android.graphics.LinearGradient
import android.graphics.Shader
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import androidx.core.content.withStyledAttributes
import androidx.core.graphics.toColorInt
import com.cy.ease.ui.R
import com.cy.ease.ui.StateType
import com.cy.ease.ui.text.IStateText
import com.cy.ease.ui.text.StateTextDelegate

/**
 * ShapedEditText
 * @author: MasterChan
 * @date: 2025-11-25 15:33
 */
open class ShapedEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatEditText(context, attrs, defStyleAttr),
    IShapedView by ShapedViewDelegate(context, attrs),
    IStateText by StateTextDelegate(context, attrs) {

    private var colorStr: String? = null
    private var positionStr: String? = null
    private var gradientOrientation: Int = 0
    private var gradientShader: LinearGradient? = null

    init {
        this.init()
        initTextGradient(attrs)
        context.withStyledAttributes(attrs, R.styleable.ShapedEditText) {
            isFocusableInTouchMode = getBoolean(
                R.styleable.ShapedEditText_android_focusableInTouchMode, true
            )
        }
    }

    protected open fun init() {
        into(this)
        setStateTextTarget(this).setStateTextStateType(stateType)
    }

    override fun setStateType(stateType: StateType): IShapedView {
        setStateTextStateType(stateType)
        return super.setStateType(stateType)
    }

    protected fun initTextGradient(attrs: AttributeSet?) {
        context.withStyledAttributes(attrs, R.styleable.ShapedEditText) {
            colorStr = getString(R.styleable.ShapedEditText_cy_textGradientColor)
            positionStr = getString(R.styleable.ShapedEditText_cy_textGradientPosition)
            gradientOrientation = getInteger(
                R.styleable.ShapedEditText_cy_textGradientOrientation, 0
            )
        }
    }

    private fun setGradient() {
        val colors = colorStr!!.split(",").map { it.toColorInt() }.toIntArray()
        val position = positionStr?.split(",")?.map { it.toFloat() }?.toFloatArray()
        if (gradientShader == null) {
            gradientShader = if (gradientOrientation == 0) {
                LinearGradient(
                    0f, 0f, width.toFloat(), 0f, colors, position, Shader.TileMode.CLAMP
                )
            } else {
                LinearGradient(
                    0f, 0f, 0f, height.toFloat(), colors, position, Shader.TileMode.CLAMP
                )
            }
        }
        paint.shader = gradientShader
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (!colorStr.isNullOrEmpty()) {
            setGradient()
        }
    }
}