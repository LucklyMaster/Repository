package com.cy.ease.ui.shadow

import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView
import com.cy.ease.ui.StateType
import com.cy.ease.ui.text.IStateText
import com.cy.ease.ui.text.StateTextDelegate

/**
 * ShadowTextView
 * @author: MasterChan
 * @date: 2025-05-07 11:13
 */
open class ShadowTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatTextView(context, attrs, defStyleAttr),
    IShadowView by ShadowViewDelegate(context, attrs),
    IStateText by StateTextDelegate(context, attrs) {

    init {
        this.init()
    }

    protected open fun init() {
        into(this)
        setStateTextTarget(this).setStateTextStateType(stateType)
    }

    override fun setStateType(stateType: StateType): IShadowView {
        setStateTextStateType(stateType)
        return super.setStateType(stateType)
    }
}