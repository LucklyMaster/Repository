package com.cy.ease.ui.dialog

import androidx.annotation.ColorInt
import androidx.annotation.GravityInt
import androidx.core.graphics.toColorInt
import com.cy.ease.ui.dialog.animator.AbsDialogAnimator
import com.cy.ease.ui.dialog.animator.BgAnimator

/**
 * IDialog
 * @author: MasterChan
 * @date: 2023-12-20 14:14
 */
interface IDialog {
    /**
     * contentView的宽度，null表示使用xml中设置的宽度
     */
    var contentWidth: Int?

    /**
     * contentView的高度，null表示使用xml中设置的高度
     */
    var contentHeight: Int?

    /**
     * 点击返回键消失
     */
    var isDismissOnBackPressed: Boolean

    /**
     * 点击外部消失
     */
    var isDismissOnTouchOutside: Boolean

    /**
     * 点击外部，是否收起键盘；当[isDismissOnTouchOutside]也为true时，
     * 如果此时键盘弹出，优先隐藏键盘
     */
    var isHideKeyboardOnTouchOutside: Boolean

    /**
     * 是否当弹出键盘时，dialog移动到键盘之上
     */
    val isUpKeyboard: Boolean

    /**
     * 是否允许将Dialog外的事件发送到后面的视图
     */
    var isTouchThrough: Boolean

    /**
     * ContentView的x方向偏移
     */
    var offsetX: Int

    /**
     * ContentView的y方向偏移
     */
    var offsetY: Int

    /**
     * 背景的动画
     */
    var bgAnimator: BgAnimator?

    /**
     * contentView的动画
     */
    var contentAnimator: AbsDialogAnimator?

    /**
     * 动画时长
     */
    var animatorDuration: Long

    /**
     * 是否启用动画，包括ContentView的动画和背景动画
     */
    var enableAnimator: Boolean

    /**
     * 背景的颜色
     */
    var bgColor: Int

    /**
     * 背景是否高斯模糊
     */
    var isBgBlur: Boolean

    /**
     * contentView的位置，修改后会覆盖XML中的设置
     */
    var contentGravity: Int

    /**
     * 是否隐藏NavigationBar
     */
    var isHideNavigationBar: Boolean

    /**
     * NavigationBar是否是亮色，null为默认
     */
    var isNavigationBarLight: Boolean?

    /**
     * 是否隐藏StatusBar
     */
    var isHideStatusBar: Boolean

    /**
     * StatusBar是否是亮色，null为默认
     */
    var isStatusBarLight: Boolean?

    /**
     * 用于标识Dialog
     */
    var tag: String

    fun setContentWidth(contentWidth: Int?) = apply {
        this.contentWidth = contentWidth
    }

    fun setContentHeight(contentHeight: Int?) = apply {
        this.contentHeight = contentHeight
    }

    fun setDismissOnBackPressed(isDismissOnBackPressed: Boolean) = apply {
        this.isDismissOnBackPressed = isDismissOnBackPressed
    }

    fun setDismissOnTouchOutside(isDismissOnTouchOutside: Boolean) = apply {
        this.isDismissOnTouchOutside = isDismissOnTouchOutside
    }

    fun setHideKeyboardOnTouchOutside(isHideKeyboardOnTouchOutside: Boolean) =
        apply {
            this.isHideKeyboardOnTouchOutside = isHideKeyboardOnTouchOutside
        }

    fun setTouchThrough(isTouchThrough: Boolean) = apply {
        this.isTouchThrough = isTouchThrough
    }

    fun setOffsetX(offsetX: Int) = apply {
        this.offsetX = offsetX
    }

    fun setOffsetY(offsetY: Int) = apply {
        this.offsetY = offsetY
    }

    fun setContentAnimator(animator: AbsDialogAnimator) = apply {
        this.contentAnimator = animator
    }

    fun setBgAnimator(animator: BgAnimator) = apply {
        this.bgAnimator = animator
    }

    fun setAnimatorDuration(animatorDuration: Long) = apply {
        this.animatorDuration = animatorDuration
    }

    fun setEnableAnimator(enableAnimator: Boolean) = apply {
        this.enableAnimator = enableAnimator
    }

    fun setBgColor(@ColorInt maskColor: Int) = apply {
        this.bgColor = maskColor
    }

    fun setBgColor(maskColor: String) = apply {
        setBgColor(maskColor.toColorInt())
    }

    fun setBgBlur(isBlur: Boolean) = apply {
        this.isBgBlur = isBlur
    }

    fun setContentGravity(@GravityInt contentGravity: Int) = apply {
        this.contentGravity = contentGravity
    }

    fun setHideNavigationBar(isHideNavigationBar: Boolean) = apply {
        this.isHideNavigationBar = isHideNavigationBar
    }

    fun setNavigationBarLight(isNavigationBarLight: Boolean?) = apply {
        this.isNavigationBarLight = isNavigationBarLight
    }

    fun setHideStatusBar(isHideStatusBar: Boolean) = apply {
        this.isHideStatusBar = isHideStatusBar
    }

    fun setStatusBarLight(isStatusBarLight: Boolean?) = apply {
        this.isStatusBarLight = isStatusBarLight
    }

    fun update(x: Int, y: Int)

    fun show(tag: String? = null) = apply { }

    fun dismiss(delay: Long = 0)
}