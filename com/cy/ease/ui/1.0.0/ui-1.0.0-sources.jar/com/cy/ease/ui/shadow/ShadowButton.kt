package com.cy.ease.ui.shadow

import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatButton
import com.cy.ease.ui.StateType
import com.cy.ease.ui.text.IStateText
import com.cy.ease.ui.text.StateTextDelegate

/**
 * ShapedButton
 * @author: MasterChan
 * @date: 2023-03-11 21:36
 */
open class ShadowButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatButton(context, attrs, defStyleAttr),
    IShadowView by ShadowViewDelegate(context, attrs),
    IStateText by StateTextDelegate(context, attrs) {

    init {
        this.init()
    }

    protected open fun init() {
        into(this)
        setStateTextTarget(this).setStateTextStateType(stateType)
    }

    override fun setStateType(stateType: StateType): IShadowView {
        setStateTextStateType(stateType)
        return super.setStateType(stateType)
    }
}