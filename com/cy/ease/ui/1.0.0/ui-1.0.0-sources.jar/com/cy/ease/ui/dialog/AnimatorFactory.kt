package com.cy.ease.ui.dialog

import com.cy.ease.ui.dialog.animator.BgAnimator
import com.cy.ease.ui.dialog.animator.ContentAnimator

/**
 * AnimatorFactory
 * @author: MasterChan
 * @date: 2025-12-22 11:11
 */
open class AnimatorFactory {
    open fun createContentAnimator(): ContentAnimator {
        return ContentAnimator()
    }

    open fun createBgAnimator(): BgAnimator {
        return BgAnimator()
    }
}