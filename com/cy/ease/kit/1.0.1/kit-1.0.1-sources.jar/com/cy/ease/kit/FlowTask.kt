package com.cy.ease.kit

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * 串行任务流管理器
 *
 * 1. 同步顺序执行：上一个任务彻底结束（如果是异步任务则需调用 taskDone）才会执行下一个。
 * 2. 支持异步任务：通过 TaskScope 作用域控制任务生命周期。
 * 3. 支持插队机制：可将任务投递至队首。
 * 4. 支持任务移除：可移除排队中任务，或立即中断正在运行的任务并自动衔接下一个任务。
 * @author: Cy
 * @date: 2026-04-11 18:18
 */
class FlowTask(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
) {
    private val queue = ArrayDeque<TaskHandle>()
    private val mutex = Mutex()
    private val signal = Channel<Unit>(Channel.CONFLATED)

    // 追踪当前正在运行的任务句柄及其协程 Job
    private var currentHandle: TaskHandle? = null
    private var currentJob: Job? = null

    init {
        scope.launch {
            while (isActive) {
                val handle = mutex.withLock {
                    if (queue.isNotEmpty()) queue.removeFirst() else null
                }

                if (handle != null) {
                    val taskJob = launch {
                        try {
                            handle.task()
                        } catch (_: CancellationException) {
                            // 任务被外部 remove 取消，忽略异常
                        } catch (e: Exception) {
                            // 任务内部异常
                            e.printStackTrace()
                        }
                    }

                    mutex.withLock {
                        currentHandle = handle
                        currentJob = taskJob
                    }

                    // 挂起并等待当前任务执行完毕或被取消
                    taskJob.join()

                    mutex.withLock {
                        currentHandle = null
                        currentJob = null
                    }
                } else {
                    signal.receive()
                }
            }
        }
    }

    fun post(block: suspend () -> Unit): TaskHandle {
        return wrapAndEnqueue(isFirst = false, block = block)
    }

    fun postFirst(block: suspend () -> Unit): TaskHandle {
        return wrapAndEnqueue(isFirst = true, block = block)
    }

    fun postAsync(block: suspend TaskScope.() -> Unit): TaskHandle {
        return wrapAndEnqueue(isFirst = false, isAsync = true, asyncBlock = block)
    }

    fun postAsyncFirst(block: suspend TaskScope.() -> Unit): TaskHandle {
        return wrapAndEnqueue(isFirst = true, isAsync = true, asyncBlock = block)
    }

    private fun wrapAndEnqueue(
        isFirst: Boolean,
        isAsync: Boolean = false,
        block: (suspend () -> Unit)? = null,
        asyncBlock: (suspend TaskScope.() -> Unit)? = null
    ): TaskHandle {
        val taskLogic: suspend () -> Unit = {
            if (isAsync) {
                val deferred = CompletableDeferred<Unit>()
                val scope = object : TaskScope {
                    override fun taskDone() {
                        if (deferred.isActive) deferred.complete(Unit)
                    }
                }
                // 执行任务
                asyncBlock?.invoke(scope)
                // 等待任务，直到外部调用了 taskDone() 或者协程被 cancel
                deferred.await()
            } else {
                block?.invoke()
            }
        }

        val handle = TaskHandle(taskLogic)

        scope.launch {
            mutex.withLock {
                if (isFirst) queue.addFirst(handle) else queue.addLast(handle)
            }
            signal.trySend(Unit)
        }

        return handle
    }

    /**
     * 移除任务。
     * 若任务还在排队中，直接从队列移除。
     * 若任务已经在运行，立即中断该任务并跳向下一个。
     */
    fun remove(handle: TaskHandle?) {
        if (handle == null) return
        scope.launch {
            mutex.withLock {
                if (handle == currentHandle) {
                    // 中断正在运行的任务协程
                    currentJob?.cancel()
                    currentHandle = null
                    currentJob = null
                } else {
                    queue.remove(handle)
                }
            }
        }
    }

    fun stop() {
        signal.close()
        scope.cancel()
    }

    interface TaskScope {
        fun taskDone()
    }

    class TaskHandle internal constructor(internal val task: suspend () -> Unit)
}