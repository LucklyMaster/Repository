package com.cy.ease.kit.ext

fun Map<Any, Any>?.sizeOrElse(size: Int): Int {
    return this?.size ?: size
}

fun Map<Any, Any>?.sizeOrElse(size: () -> Int): Int {
    return this?.size ?: size()
}