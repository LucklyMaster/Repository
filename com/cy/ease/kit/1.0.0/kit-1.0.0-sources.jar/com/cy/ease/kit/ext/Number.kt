package com.cy.ease.kit.ext

import com.cy.ease.kit.utils.RegexPool
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale

fun Number?.format(digits: Int = 2, isRound: Boolean = true): String {
    // 1. 处理空值，转换为 Double
    val value = this?.toDouble() ?: 0.0

    // 2. 确定舍入模式
    // HALF_UP: 四舍五入
    // DOWN: 直接截断
    val mode = if (isRound) RoundingMode.HALF_UP else RoundingMode.DOWN

    // 3. 使用 BigDecimal 进行精确处理
    // 使用 value.toString() 构造可以避免 Double 精度丢失问题
    val result = BigDecimal(value.toString())
        .setScale(digits, mode)

    // 4. 强制使用 Locale.US 以确保小数点始终为 "."，并补齐末尾的 0
    return String.format(Locale.US, "%.${digits}f", result.toDouble())
}

/**
 * 去除数字（包含小数）末尾多余的 0
 *
 * 例如：
 *
 * - "12.3400" -> "12.34"
 * - "1.0"     -> "1"
 * - "100.00"  -> "100"
 * - "100"     -> "100"
 *
 * @return 处理后的字符串，若非数字或无小数点则返回原字符串
 */
fun String?.trimTrailingZeros(): String {
    if (this == null) return ""
    if (!this.contains(".")) return this

    // 使用正则替换：
    // 第一部分 (\\.\\d*?[1-9])0+$ 匹配保留非零数字后的零
    // 第二部分 \\.0+$ 匹配点后面全都是零的情况
    return this.replace(RegexPool.trailingZeros, "$1")
}

/**
 * 将数值转换为字符串后，自动去除数字末尾的 0
 */
fun Number?.trimTrailingZeros(): String = this?.toString().trimTrailingZeros()