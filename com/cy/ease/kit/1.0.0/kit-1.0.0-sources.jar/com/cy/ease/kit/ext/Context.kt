package com.cy.ease.kit.ext

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.os.Build
import android.os.Process
import android.util.DisplayMetrics
import android.view.View
import android.view.WindowManager
import androidx.core.app.ActivityOptionsCompat

/**
 * 获取当前进程名称
 */
val Context.processName: String?
    get() {
        val activityManager = getSystemService(ActivityManager::class.java)
        activityManager.runningAppProcesses?.forEach {
            if (it.pid == Process.myPid()) {
                return it.processName
            }
        }
        return null
    }

/**
 * 是否是主进程
 */
val Context.isMainProcess: Boolean
    get() = processName == packageName

/**
 * 获取屏幕宽度（像素）
 */
val Context.screenWidth: Int
    get() {
        return resources.displayMetrics.widthPixels
    }

/**
 * 获取屏幕高度（像素）
 */
val Context.screenHeight: Int
    get() {
        return resources.displayMetrics.heightPixels
    }

/**
 * 获取屏幕真实宽度（包含导航栏等系统栏）
 */
val Context.screenRealWidth: Int
    get() {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val windowManager = getSystemService(WindowManager::class.java)
            val metrics = windowManager.currentWindowMetrics
            metrics.bounds.width()
        } else {
            val displayMetrics = DisplayMetrics()
            val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(displayMetrics)
            displayMetrics.widthPixels
        }
    }

/**
 * 获取屏幕真实高度（包含导航栏等系统栏）
 */
val Context.screenRealHeight: Int
    get() {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val windowManager = getSystemService(WindowManager::class.java)
            val metrics = windowManager.currentWindowMetrics
            metrics.bounds.height()
        } else {
            val displayMetrics = DisplayMetrics()
            val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(displayMetrics)
            displayMetrics.heightPixels
        }
    }

/**
 * 获取状态栏高度
 */
val Context.statusBarHeight: Int
    get() {
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resourceId > 0) resources.getDimensionPixelSize(resourceId) else 0
    }

/**
 * 获取导航栏高度
 */
val Context.navigationBarHeight: Int
    get() {
        val resourceId = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        return if (resourceId > 0) resources.getDimensionPixelSize(resourceId) else 0
    }

/**
 * 获取屏幕密度
 */
val Context.displayDensity: Float
    get() = resources.displayMetrics.density

/**
 * 获取字体缩放密度
 */
val Context.scaledDensity: Float
    get() = resources.displayMetrics.scaledDensity

/**
 * 从 Context 中获取 Activity 实例
 */
val Context.activity: Activity?
    get() {
        var currContext = this
        while (currContext is ContextWrapper) {
            if (currContext is Activity) return currContext
            currContext = currContext.baseContext
        }
        return null
    }

/**
 * 启动指定的 Activity
 * @param clazz Activity 类对象
 */
fun Context.startActivity(clazz: Class<out Activity>) {
    startActivity(Intent(this, clazz))
}

/**
 * 使用泛型启动 Activity
 * @param params Intent 配置闭包
 */
inline fun <reified T : Activity> Context.startActivity(noinline params: (Intent.() -> Unit)? = null) {
    val intent = Intent(this, T::class.java)
    params?.invoke(intent)
    startActivity(intent)
}

/**
 * 使用泛型启动 Activity 并指定切换动画
 * @param enterAnimate 进入动画资源 ID
 * @param exitAnimate 退出动画资源 ID
 * @param params Intent 配置闭包
 */
inline fun <reified T : Activity> Context.startActivity(
    enterAnimate: Int,
    exitAnimate: Int,
    noinline params: (Intent.() -> Unit)? = null
) {
    val intent = Intent(this, T::class.java)
    params?.invoke(intent)
    val bundle = ActivityOptionsCompat.makeCustomAnimation(this, enterAnimate, exitAnimate)
        .toBundle()
    startActivity(intent, bundle)
}

/**
 * 使用泛型启动 Activity 并指定共享元素动画
 * @param sharedElements 共享元素视图与名称的键值对
 * @param params Intent 配置闭包
 */
inline fun <reified T : Activity> Context.startActivity(
    vararg sharedElements: Pair<View, String>,
    noinline params: (Intent.() -> Unit)? = null
) {
    val intent = Intent(this, T::class.java)
    params?.invoke(intent)
    val activity = activity
    if (sharedElements.isNotEmpty() && activity != null) {
        val array = Array(sharedElements.size) {
            androidx.core.util.Pair(sharedElements[it].first, sharedElements[it].second)
        }
        startActivity(
            intent, ActivityOptionsCompat.makeSceneTransitionAnimation(activity, *array).toBundle()
        )
    } else {
        startActivity(intent)
    }
}
