package com.cy.ease.kit.initializer

import android.content.Context

/**
 * 实现自己的初始化，由[AppInitializer]管理
 * @author: MasterChan
 * @date: 2026-04-01 13:21
 */
interface Initializer {
    suspend fun init(context: Context)
}