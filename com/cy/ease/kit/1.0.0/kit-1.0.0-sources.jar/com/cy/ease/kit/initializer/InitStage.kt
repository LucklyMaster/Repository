package com.cy.ease.kit.initializer

enum class InitStage {
    SYNC,
    ASYNC,
}