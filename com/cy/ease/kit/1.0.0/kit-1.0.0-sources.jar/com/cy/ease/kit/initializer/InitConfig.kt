package com.cy.ease.kit.initializer

/**
 * 初始化任务配置类
 * @author: MasterChan
 * @date: 2026-04-01 13:22
 */
data class InitConfig(
    /**
     * 初始化实现
     */
    val initializer: Initializer,
    /**
     * 自定义的[initializer]名称
     */
    val name: String,
    /**
     * 初始化时使用的协程上下文
     */
    val stage: InitStage = InitStage.SYNC,
    /**
     * 依赖的[Initializer]，需要在他们之后完成初始化
     */
    val dependencies: List<String> = emptyList()
)
