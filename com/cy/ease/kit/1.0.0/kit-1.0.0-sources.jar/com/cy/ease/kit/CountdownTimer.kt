package com.cy.ease.kit

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * 使用Kotlin协程和StateFlow的倒计时器实现。
 *
 * 此类提供了一种被动方式来跟踪剩余时间和当前运行状态。支持启动、暂停、恢复
 *
 * @property scope 协程。默认为[Dispatchers.Main]
 *
 * @author: Administrator
 * @date: 2026-04-09 22:44
 */
class CountdownTimer(private val scope: CoroutineScope = CoroutineScope(Dispatchers.Main + Job())) {
    private var timerJob: Job? = null

    // 剩余毫秒数
    private val _remainingTime = MutableStateFlow(0L)
    val remainingTime = _remainingTime.asStateFlow()

    // 运行状态
    private val _isRunning = MutableStateFlow(false)
    val isRunning = _isRunning.asStateFlow()

    private var totalTime = 0L

    /**
     * 开始倒计时
     * @param millisInFuture 总毫秒数
     * @param countDownInterval 步进间隔
     */
    fun start(millisInFuture: Long, countDownInterval: Long = 1000L) {
        if (_isRunning.value) return

        this.totalTime = millisInFuture
        _remainingTime.value = millisInFuture

        runTimer(countDownInterval)
    }

    private fun runTimer(interval: Long) {
        timerJob?.cancel()
        timerJob = scope.launch {
            _isRunning.value = true
            while (_remainingTime.value > 0) {
                delay(interval)
                val nextTime = _remainingTime.value - interval
                _remainingTime.value = if (nextTime < 0) 0 else nextTime
            }
            _isRunning.value = false
        }
    }

    /**
     * 暂停
     */
    fun pause() {
        timerJob?.cancel()
        _isRunning.value = false
    }

    /**
     * 恢复
     */
    fun resume(countDownInterval: Long = 1000L) {
        if (_isRunning.value || _remainingTime.value <= 0) return
        runTimer(countDownInterval)
    }

    /**
     * 停止/重置
     */
    fun stop() {
        timerJob?.cancel()
        _remainingTime.value = 0
        _isRunning.value = false
    }

    /**
     * 释放资源
     */
    fun release() {
        timerJob?.cancel()
        scope.cancel()
    }
}