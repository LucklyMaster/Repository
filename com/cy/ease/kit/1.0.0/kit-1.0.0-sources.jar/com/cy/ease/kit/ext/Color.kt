package com.cy.ease.kit.ext

import android.content.res.ColorStateList
import android.view.View
import androidx.annotation.ColorRes
import androidx.core.graphics.toColorInt

fun View.getColor(@ColorRes resId: Int): Int = context.getColor(resId)

fun Int.toColorStateList(): ColorStateList = ColorStateList.valueOf(this)

fun String.toColorStateList(): ColorStateList = ColorStateList.valueOf(this.toColorInt())