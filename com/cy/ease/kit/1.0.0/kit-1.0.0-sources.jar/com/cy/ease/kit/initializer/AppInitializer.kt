package com.cy.ease.kit.initializer

import android.content.Context
import com.cy.ease.kit.log.Logger
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 统一应用初始化管理器，用于在应用启动时按序执行各项初始化任务。
 *
 * 该工具支持：
 * 1. **依赖管理**：通过拓扑排序自动处理初始化任务之间的依赖关系，防止循环依赖。
 * 2. **分阶段执行**：支持同步 (Main) 和异步 (IO) 任务分发。
 * 3. **并发优化**：无依赖关系的独立任务将并行执行，有依赖链的任务按序串行，最大程度提升启动效率。
 *
 * @author: MasterChan
 * @date: 2026-04-06 19:31
 */
class AppInitializer {

    private val registry = mutableMapOf<String, InitConfig>()

    fun register(
        initializer: Initializer,
        name: String = initializer.javaClass.name,
        stage: InitStage = InitStage.SYNC,
        dependencies: List<String> = emptyList()
    ) = apply {
        if (registry.containsKey(name)) {
            throw IllegalArgumentException("Initializer name:$name already registered")
        }
        registry[name] = InitConfig(initializer, name, stage, dependencies)
    }

    fun register(
        name: String,
        stage: InitStage = InitStage.SYNC,
        dependencies: List<String> = emptyList(),
        initializer: () -> Initializer,
    ) = apply {
        if (registry.containsKey(name)) {
            throw IllegalArgumentException("Initializer name:$name already registered")
        }
        registry[name] = InitConfig(initializer(), name, stage, dependencies)
    }

    suspend fun init(context: Context) {
        coroutineScope {
            val (groupA, groupB) = generateGroupsWithTopo(registry.values.toList())
            groupA.forEach {
                launch(it.stage.dispatchers) {
                    it.initializer.init(context)
                    Logger.Forest.d("Initializer name:${it.name} init complete")
                }
            }
            groupB.forEach { configs ->
                launch {
                    configs.forEach { cfg ->
                        withContext(cfg.stage.dispatchers) {
                            cfg.initializer.init(context)
                            Logger.Forest.d(
                                "Initializer name:${cfg.name} init complete,it depends on ${cfg.dependencies}"
                            )
                        }
                    }
                }
            }
        }
    }

    private fun generateGroupsWithTopo(list: List<InitConfig>): Pair<List<InitConfig>, List<List<InitConfig>>> {
        val map = list.associateBy { it.name }

        // 谁依赖我
        val reverseDeps = mutableMapOf<String, MutableList<String>>()
        list.forEach { cfg ->
            cfg.dependencies.forEach { dep ->
                reverseDeps.getOrPut(dep) { mutableListOf() }.add(cfg.name)
            }
        }

        val assigned = mutableSetOf<String>()

        // 组 A: 完全独立
        val groupA = list.filter { it.dependencies.isEmpty() && reverseDeps[it.name].isNullOrEmpty() }
        assigned.addAll(groupA.map { it.name })

        // 组 B: 每个依赖子图形成一个 list
        val groupsB = mutableListOf<List<InitConfig>>()

        list.forEach { cfg ->
            if (assigned.contains(cfg.name)) return@forEach

            val chainSet = mutableSetOf<String>()

            // DFS 向上和向下遍历，收集完整依赖子图
            fun dfs(node: InitConfig) {
                if (chainSet.contains(node.name)) return
                chainSet.add(node.name)
                node.dependencies.forEach { dep -> map[dep]?.let { dfs(it) } }
                reverseDeps[node.name]?.forEach { depBy -> map[depBy]?.let { dfs(it) } }
            }

            dfs(cfg)

            // 子图拓扑排序
            val chainList = topologicalSort(chainSet.map { map[it]!! })
            groupsB.add(chainList)
            assigned.addAll(chainSet)
        }

        return Pair(topologicalSort(groupA), groupsB)
    }

    // 组内拓扑排序
    private fun topologicalSort(list: List<InitConfig>): List<InitConfig> {
        val result = mutableListOf<InitConfig>()
        val visited = mutableSetOf<String>()
        val visiting = mutableSetOf<String>()
        val map = list.associateBy { it.name }

        fun dfs(node: InitConfig) {
            if (visited.contains(node.name)) return
            if (visiting.contains(node.name)) {
                throw IllegalStateException("Initializer name:${node.name} has Circular dependency")
            }
            visiting.add(node.name)
            node.dependencies.forEach { dep -> map[dep]?.let { dfs(it) } }
            visiting.remove(node.name)
            visited.add(node.name)
            result.add(node)
        }

        list.forEach { dfs(it) }
        return result
    }

    private val InitStage.dispatchers: CoroutineDispatcher
        get() = if (this == InitStage.SYNC) Dispatchers.Main else Dispatchers.IO
}