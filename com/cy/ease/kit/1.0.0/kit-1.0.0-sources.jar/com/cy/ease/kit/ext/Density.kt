package com.cy.ease.kit.ext

import android.content.Context
import android.util.TypedValue
import android.view.View

//###########################Context#############################
fun Context.dp2px(dp: Float): Float = dp * displayDensity
fun Context.dp2px(dp: Int): Float = dp * displayDensity

fun Context.dp2pxi(dp: Float): Int = (dp * displayDensity + 0.5f).toInt()
fun Context.dp2pxi(dp: Int): Int = (dp * displayDensity + 0.5f).toInt()

fun Context.px2dp(px: Float): Float = px / displayDensity
fun Context.px2dp(px: Int): Float = px / displayDensity

fun Context.px2dpi(px: Float): Int = (px / displayDensity + 0.5f).toInt()
fun Context.px2dpi(px: Int): Int = (px / displayDensity + 0.5f).toInt()


fun Context.sp2px(sp: Float): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, resources.displayMetrics)

fun Context.sp2px(sp: Int): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp.toFloat(), resources.displayMetrics)

fun Context.sp2pxi(sp: Float): Int = (sp2px(sp) + 0.5f).toInt()
fun Context.sp2pxi(sp: Int): Int = (sp2px(sp) + 0.5f).toInt()

fun Context.px2sp(px: Float) = px / scaledDensity
fun Context.px2sp(px: Int) = px / scaledDensity

fun Context.px2spi(px: Float) = (px / scaledDensity + 0.5f).toInt()
fun Context.px2spi(px: Int) = (px / scaledDensity + 0.5f).toInt()


//###########################View#############################
fun View.dp2px(dp: Float): Float = dp * context.displayDensity
fun View.dp2px(dp: Int): Float = dp * context.displayDensity

fun View.dp2pxi(dp: Float): Int = (dp * context.displayDensity + 0.5f).toInt()
fun View.dp2pxi(dp: Int): Int = (dp * context.displayDensity + 0.5f).toInt()

fun View.px2dp(px: Float): Float = px / context.displayDensity
fun View.px2dp(px: Int): Float = px / context.displayDensity

fun View.px2dpi(px: Float): Int = (px / context.displayDensity + 0.5f).toInt()
fun View.px2dpi(px: Int): Int = (px / context.displayDensity + 0.5f).toInt()


fun View.sp2px(sp: Float): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, resources.displayMetrics)

fun View.sp2px(sp: Int): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp.toFloat(), resources.displayMetrics)

fun View.sp2pxi(sp: Float): Int = (sp2px(sp) + 0.5f).toInt()
fun View.sp2pxi(sp: Int): Int = (sp2px(sp) + 0.5f).toInt()

fun View.px2sp(px: Float) = px / context.scaledDensity
fun View.px2sp(px: Int) = px / context.scaledDensity

fun View.px2spi(px: Float) = (px / context.scaledDensity + 0.5f).toInt()
fun View.px2spi(px: Int) = (px / context.scaledDensity + 0.5f).toInt()