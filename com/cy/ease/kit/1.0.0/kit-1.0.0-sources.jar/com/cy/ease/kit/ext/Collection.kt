package com.cy.ease.kit.ext

fun Collection<Any>?.sizeOrElse(size: Int): Int {
    return this?.size ?: size
}

fun Collection<Any>?.sizeOrElse(size: () -> Int): Int {
    return this?.size ?: size()
}