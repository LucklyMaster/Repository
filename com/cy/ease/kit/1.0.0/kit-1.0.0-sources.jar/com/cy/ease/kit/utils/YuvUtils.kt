package com.cy.ease.kit.utils

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.Image
import java.io.ByteArrayOutputStream

object YuvUtils {

    /**
     * 将 Camera2/CameraX 的 Image 对象转换为 NV21 格式的字节数组
     */
    fun imageToNv21(image: Image): ByteArray {
        val width = image.width
        val height = image.height
        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]

        val yBuffer = yPlane.buffer
        val uBuffer = uPlane.buffer
        val vBuffer = vPlane.buffer

        val yRowStride = yPlane.rowStride
        val uvRowStride = uPlane.rowStride
        val uvPixelStride = uPlane.pixelStride

        // NV21 占用的总字节数：宽 * 高 * 1.5
        val nv21 = ByteArray(width * height * 3 / 2)

        // 1. 复制 Y 分量
        // 考虑 rowStride 可能大于 width 的情况（内存对齐）
        var offset = 0
        for (row in 0 until height) {
            yBuffer.position(row * yRowStride)
            yBuffer.get(nv21, offset, width)
            offset += width
        }

        // 2. 复制 UV 分量 (NV21 格式：V在前，U在后，交替排列)
        val uvWidth = width / 2
        val uvHeight = height / 2

        // UV 起始偏移量是在所有的 Y 之后
        var uvOffset = width * height

        for (row in 0 until uvHeight) {
            for (col in 0 until uvWidth) {
                // 根据 PixelStride 和 RowStride 计算具体的内存位置
                val bufferPos = row * uvRowStride + col * uvPixelStride

                // NV21 顺序是 V, U, V, U...
                nv21[uvOffset++] = vBuffer.get(bufferPos)
                nv21[uvOffset++] = uBuffer.get(bufferPos)
            }
        }

        return nv21
    }

    /**
     * 将 NV21 数据转换为 Bitmap
     */
    fun nv21ToBitmap(nv21: ByteArray, width: Int, height: Int): Bitmap? {
        return try {
            val yuvImage = YuvImage(nv21, ImageFormat.NV21, width, height, null)
            val out = ByteArrayOutputStream()
            yuvImage.compressToJpeg(Rect(0, 0, width, height), 100, out)
            val imageBytes = out.toByteArray()
            BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * 旋转 NV21 数据 (支持 90, 180, 270 度)
     */
    fun rotateNv21(data: ByteArray, width: Int, height: Int, rotation: Int): ByteArray {
        if (rotation == 0) return data

        val rotatedData = ByteArray(data.size)
        val ySize = width * height
        var k = 0

        when (rotation) {
            90 -> {
                // 旋转 Y
                for (i in 0 until width) {
                    for (j in height - 1 downTo 0) {
                        rotatedData[k++] = data[j * width + i]
                    }
                }
                // 旋转 UV
                k = ySize
                val uvHeight = height / 2
                for (i in 0 until width step 2) {
                    for (j in uvHeight - 1 downTo 0) {
                        rotatedData[k++] = data[ySize + j * width + i]
                        rotatedData[k++] = data[ySize + j * width + i + 1]
                    }
                }
            }
            180 -> {
                // Y 倒序
                for (i in ySize - 1 downTo 0) rotatedData[k++] = data[i]
                // UV 倒序
                k = ySize
                for (i in data.size - 1 downTo ySize step 2) {
                    rotatedData[k + 1] = data[i]
                    rotatedData[k] = data[i - 1]
                    k += 2
                }
            }
            270 -> {
                // 逻辑同 90，方向相反
                for (i in width - 1 downTo 0) {
                    for (j in 0 until height) {
                        rotatedData[k++] = data[j * width + i]
                    }
                }
            }
        }
        return rotatedData
    }

    /**
     * 将 Bitmap 转换为 NV21
     */
    fun bitmapToNv21(src: Bitmap, width: Int, height: Int): ByteArray {
        val argb = IntArray(width * height)
        src.getPixels(argb, 0, width, 0, 0, width, height)
        val yuv = ByteArray(width * height * 3 / 2)
        encodeYV12(yuv, argb, width, height)
        return yuv
    }

    private fun encodeYV12(yuv420sp: ByteArray, argb: IntArray, width: Int, height: Int) {
        val frameSize = width * height
        var yIndex = 0
        var uvIndex = frameSize

        for (j in 0 until height) {
            for (i in 0 until width) {
                val index = j * width + i

                val pixel = argb[index]
                val r = (pixel shr 16) and 0xff
                val g = (pixel shr 8) and 0xff
                val b = pixel and 0xff

                // YUV 转换公式
                val y = (66 * r + 129 * g + 25 * b + 128 shr 8) + 16
                val u = (-38 * r - 74 * g + 112 * b + 128 shr 8) + 128
                val v = (112 * r - 94 * g - 18 * b + 128 shr 8) + 128

                // 填充 Y 分量
                yuv420sp[yIndex++] = y.coerceIn(0, 255).toByte()

                // UV 分量采样 (4:2:0 采样：每 2x2 个像素采样一组 UV)
                // 只有当行(j)和列(i)都是偶数时才进行采样
                if (j % 2 == 0 && i % 2 == 0) {
                    // NV21 格式：V 在前，U 在后
                    yuv420sp[uvIndex++] = v.coerceIn(0, 255).toByte()
                    yuv420sp[uvIndex++] = u.coerceIn(0, 255).toByte()
                }
            }
        }
    }
}