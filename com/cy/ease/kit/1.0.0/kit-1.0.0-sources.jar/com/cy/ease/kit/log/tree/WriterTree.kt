package com.cy.ease.kit.log.tree

import com.cy.ease.kit.ext.format
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File
import java.util.Date

open class WriterTree(
    var logDir: String,
    var extension: String = "log",
    var saveDays: Int = 10
) : Tree() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    protected fun obtainLogFile(): File {
        File(logDir).mkdirs()
        return File(logDir, "${Date().format("yyyyMMdd")}.${extension}")
    }

    override fun print(
        priority: Int,
        tag: String,
        message: String?,
        stackTrace: StackTraceElement?
    ) {
        scope.launch {
            try {
                val header = Date().format("yyyy-MM-dd HH:mm:ss:SS")
                var content = "$header\n  ${message?.replace("\n", "\n  ")}"
                if (message?.endsWith("\n") != true || message.endsWith("\n\r")) {
                    content += "\n"
                }
                obtainLogFile().appendText(content)
            } catch (t: Throwable) {
                t.printStackTrace()
            }
        }
    }

    fun deleteOverdue() {
        scope.launch(Dispatchers.IO) {
            val logDir = File(logDir)
            runCatching {
                if (!logDir.exists()) return@runCatching
                val now = System.currentTimeMillis()
                val expireTime = saveDays * 24 * 60 * 60 * 1000L
                logDir.listFiles()?.forEach {
                    if (now - it.lastModified() > expireTime) {
                        it.delete()
                    }
                }
            }
        }
    }
}