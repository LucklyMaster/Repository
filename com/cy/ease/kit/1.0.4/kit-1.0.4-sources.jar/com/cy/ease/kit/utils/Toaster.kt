package com.cy.ease.kit.utils

import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.widget.TextView
import android.widget.Toast
import com.cy.ease.kit.EaseKit
import com.cy.ease.kit.R
import com.cy.ease.kit.ext.isMainThread
import com.cy.ease.kit.log.Logger

object Toaster {

    private var toaster: Toast? = null

    private val handler = Handler(Looper.getMainLooper())

    var config = Config()

    fun show(text: String, config: (Config) -> Config = { it }) {
        doShow(text, Toast.LENGTH_SHORT, config(this.config.copy()))
    }

    fun showLong(text: String, config: (Config) -> Config = { it }) {
        doShow(text, Toast.LENGTH_LONG, config(this.config.copy()))
    }

    private fun doShow(text: String, duration: Int = Toast.LENGTH_SHORT, config: Config) {
        if (!isMainThread) {
            handler.post { doShow(text, duration, config) }
            return
        }

        toaster?.cancel()

        toaster = Toast.makeText(EaseKit.app, "", duration).apply {
            if (config.viewRes != 0) {
                this.view = LayoutInflater.from(EaseKit.app).inflate(config.viewRes, null).apply {
                    findViewById<TextView>(R.id.tv_toast_message).text = text
                }
            } else {
                setText(text)
            }
            this.duration = duration
            setGravity(config.gravity, config.xOffset, config.yOffset)
        }

        toaster?.show()
        Logger.Forest.d(message = "Toaster->$text")
    }

    data class Config(
        var gravity: Int = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL,
        var xOffset: Int = 0,
        var yOffset: Int = 200,
        var viewRes: Int = 0
    )
}