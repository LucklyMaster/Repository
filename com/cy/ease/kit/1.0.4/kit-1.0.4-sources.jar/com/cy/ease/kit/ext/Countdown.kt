package com.cy.ease.kit.ext

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

fun Long.countdown(step: Long = 1_000L): Flow<Long> = flow {
    var remain = this@countdown
    while (remain > 0) {
        emit(remain)
        delay(step)
        remain -= step
    }
    emit(0L)
}

fun Int.countdown(step: Long = 1_000): Flow<Long> = toLong().countdown(step)