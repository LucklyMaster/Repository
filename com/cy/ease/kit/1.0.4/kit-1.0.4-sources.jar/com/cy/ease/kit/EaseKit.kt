package com.cy.ease.kit

import android.annotation.SuppressLint
import android.app.Application

@SuppressLint("StaticFieldLeak")
object EaseKit {
    internal lateinit var app: Application

    fun init(app: Application) {
        this.app = app
        ActivityStack.init(app)
    }
}