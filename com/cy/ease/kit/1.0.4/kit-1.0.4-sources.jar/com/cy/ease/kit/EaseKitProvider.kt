package com.cy.ease.kit

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import com.cy.ease.kit.ext.cast
import com.cy.ease.kit.ext.isMainProcess

/**
 * PortedKitProvider
 * @author: Cy
 * @date: 2026-04-09 10:00
 */
class EaseKitProvider : ContentProvider() {

    override fun onCreate(): Boolean {
        if (context?.isMainProcess == true) {
            EaseKit.init(context!!.applicationContext.cast())
            return true
        }
        return false
    }

    override fun delete(
        uri: Uri,
        selection: String?,
        selectionArgs: Array<out String?>?
    ): Int = 0

    override fun getType(uri: Uri): String? = null

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun query(
        uri: Uri,
        projection: Array<out String?>?,
        selection: String?,
        selectionArgs: Array<out String?>?,
        sortOrder: String?
    ): Cursor? = null

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<out String?>?
    ): Int = 0
}